using System.Configuration;
using System.Drawing;

namespace PRACTICA_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double v1, farh1;

            v1 = double.Parse(textBox1.Text);

            farh1 = v1 * (9.0 / 5.0) + 32;

            textBox2.Text = farh1.ToString();

            label2.Text = " Fahrenheit";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            double v1, cent1;

            v1 = double.Parse(textBox1.Text);

            cent1 = (v1 - 32) * (5.0 / 9.0); textBox2.Text = cent1.ToString();

            label2.Text = " Centigrados";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

textBox2.Text = " ";

textBox2.Text = " ";
        }
    }
}
