namespace PRACTICA_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n, count = 0, limite;

            n = int.Parse(textBox1.Text);

            limite = int.Parse(textBox2.Text);

            do

            {

                listBox1.Items.Add(n + 10 * +count + "=" + n * count);

                count++;

            } while (count <= limite);
        }
    }
}
