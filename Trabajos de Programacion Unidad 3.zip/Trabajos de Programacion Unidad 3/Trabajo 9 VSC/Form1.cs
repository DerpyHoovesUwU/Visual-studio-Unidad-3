using System;
using System.Numerics;

namespace PRACTICA_9
{
    public partial class Form1 : Form
    {
        float f_num, Total = 0;        
        public Form1()
        {
            InitializeComponent();
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {


        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Bot�n A�adir

            listBox1.Items.Add(textBox1.Text);

            //Aqui es donde pasamos el par�metro

            f_num = float.Parse(textBox1.Text);
            Total += f_num;
            textBox1.Text = " ";
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Bot�n SumarNumeros

            textBox2.Text = Total.ToString();
        }
    }
}
